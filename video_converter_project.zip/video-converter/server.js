
const express = require("express");
const multer = require("multer");
const cors = require("cors");
const ffmpeg = require("fluent-ffmpeg");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(cors());
app.use(express.static("public"));

const upload = multer({ dest: "uploads/" });

app.post("/convert", upload.single("video"), (req, res) => {
  const format = req.body.format || "mp4";
  const target = req.body.size || "100"; // in MB (just for naming)

  const inputPath = req.file.path;
  const outputPath = `converted/output-${Date.now()}.${format}`;

  ffmpeg(inputPath)
    .videoCodec("libx264")
    .outputOptions(["-preset fast", "-crf 28"])
    .on("end", () => {
      fs.unlinkSync(inputPath);
      res.json({ success: true, url: `/${outputPath}` });
    })
    .on("error", (err) => {
      console.error(err);
      res.status(500).send("Conversion failed");
    })
    .save(outputPath);
});

app.use("/converted", express.static("converted"));

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
        